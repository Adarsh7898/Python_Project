let contributors = [
  {
    github: "https://github.com/Pranjal360Agarwal",
    name: "Pranjal Agarwal",
    linkedin: "https://www.linkedin.com/in/pranjal-agarwal-11b543226/",
  },
  {
    github: "https://github.com/shrey141102",
    name: "Shreyansh Khaitan",
    linkedin: "https://www.linkedin.com/in/shreyansh-khaitan/",
  },
  {
      github: "https://github.com/hdmtp",
      name: "Pritam Dhara",
      linkedin: "https://www.linkedin.com/in/hdmtp/",
    },
  {
      github: "https://github.com/Sapt-pal",
      name: "Saptarshi Pal",
      linkedin: "https://www.linkedin.com/in/Sapt-pal/",
    },
  {
      github: "https://github.com/jainsujan11",
      name: "Sujan Jain",
    },
  {
    GitHub: "https://github.com/yashpatel08",
    name: "Patel Yash",
    linkedin: "https://www.linkedin.com/in/yash-patel-ab2740225/",
  },
  {
    GitHub: "https://github.com/Codeblade98",
    name: "Agnij Biswas",
    linkedin: "https://www.linkedin.com/in/agnij-biswas-82a62124a/",
    
  },
  {
    GitHub: "https://github.com/YashGovil",
    name: "Yash Govil",
    linkedin: "https://www.linkedin.com/in/yash-govil-26762722a/",
  },
  {
    GitHub: "https://github.com/devichand579",
    name: "Devichand",
    linkedin: "https://www.linkedin.com/in/devichand-budagam-834b2322a",
  },
  {
    Github: "https://github.com/Garvit414",
    Name: "Garvit Agarwal",
    Linkedin: "https://www.linkedin.com/in/garvit-agarwal-675b81229/"
  },
  {
    GitHub: "https://github.com/ManasviEmmadi",
    Name: "Manasvi Emmadi",
    Linkedin: "https://www.linkedin.com/in/manasvi-emmadi-05425320b/"
  },
  {
    GitHub: "https://github.com/Sahajj",
    Name: "Sahaj Jain",
    Linkedin: "https://www.linkedin.com/in/sahaj-jain-410100228/"
  },
  {
    GitHub: "https://github.com/can-ishk",
    Name: "Kanishk Chathley",
    Linkedin: "https://www.linkedin.com/in/kanishk-chathley/"
  },
  {
    GitHub: "https://github.com/blip100",
    Name: "parthiv reddy",
    Linkedin: "https://www.linkedin.com/in/parthiv-reddy-b39113223/"
  },
  {
    github: "https://github.com/Krishnadeshpande2907",
    name: "Krishna Deshpande",
    linkedin: "https://www.linkedin.com/in/krishna-deshpande-347188223/",
  },
  {
    github: "https://github.com/Uncle-Pi",
    name: "Sumit Bagchi",
    linkedin: "https://www.linkedin.com/in/sumit-bagchi-b66576236/",
  },
  {
    github: "https://github.com/KrishGaur1354",
    name: "Krish Gaur",
    linkedin: "https://www.linkedin.com/in/thatonekrish/",
  },
  {
   github: "https://github.com/Bharadwajshivam28",
    name: "Shivam Kumar",
    linkedin: "https://www.linkedin.com/in/shivam-kumar-70a746256/",
    },
  {
    github: "https://github.com/ravikumar117211",
    name: "Ravi Kumar",
    linkedin: "https://www.linkedin.com/in/ravikumar117211/",
  },
  {
    GitHub: "https://github.com/Dragonstac",
    name: "Shreyash Srivastava",
    linkedin: "https://www.linkedin.com/in/dragonstac/",
  },
  {
    GitHub: "https://github.com/gulshanjakhon",
    name: "Gulshan Kumar Jakhon",
    linkedin: "https://linkedin.com/in/gulshankumarjakhon/",
  }
  ];
