import os

os.chdir("./bus-booking-system")
os.system("python main.py")
